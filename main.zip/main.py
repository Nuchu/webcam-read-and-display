from cam import *
import cv2
import numpy as np
readcam()
